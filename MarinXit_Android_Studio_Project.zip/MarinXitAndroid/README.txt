MARIN XIT — projeto Android de overlay visual

Este projeto é uma demonstração visual independente. Não lê, modifica ou interage com Free Fire.

Como gerar o APK:
1. Abra o projeto no Android Studio (File > Open) e selecione esta pasta.
2. Aguarde a sincronização do Gradle.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
4. No celular, instale o APK gerado.
5. Abra Marin Xit e toque em “Ativar bolinha flutuante”.
6. Autorize “Exibir sobre outros apps” nas configurações do Android.
7. A bolinha pode ser arrastada; toque nela para abrir o painel.
