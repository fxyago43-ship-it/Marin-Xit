package com.marinxit.overlay;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.graphics.drawable.GradientDrawable;

public class OverlayService extends Service {
    private WindowManager wm;
    private FrameLayout bubble;
    private WebView web;
    private View panelContainer;
    private WindowManager.LayoutParams bubbleParams, panelParams;

    private int overlayType() {
        return Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
    }
    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        showBubble();
    }
    private void showBubble() {
        if (bubble != null) return;
        bubble = new FrameLayout(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0xff06200d);
        bg.setStroke(3, 0xff00ff55);
        bubble.setBackground(bg);
        ImageView icon = new ImageView(this);
        try {
            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeStream(getAssets().open("watermelon.png"));
            icon.setImageBitmap(bmp);
            icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } catch (Exception ignored) {}
        bubble.addView(icon, new FrameLayout.LayoutParams(-1, -1));
        bubble.setClipToOutline(true);
        bubbleParams = new WindowManager.LayoutParams(dp(66), dp(66), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = dp(12); bubbleParams.y = dp(220);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; long downAt;
            public boolean onTouch(View v, MotionEvent e) {
                switch(e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX=e.getRawX(); downY=e.getRawY(); startX=bubbleParams.x; startY=bubbleParams.y; downAt=System.currentTimeMillis(); return true;
                    case MotionEvent.ACTION_MOVE:
                        bubbleParams.x=startX+(int)(e.getRawX()-downX);
                        bubbleParams.y=startY+(int)(e.getRawY()-downY);
                        wm.updateViewLayout(bubble,bubbleParams); return true;
                    case MotionEvent.ACTION_UP:
                        if (Math.abs(e.getRawX()-downX)<12 && Math.abs(e.getRawY()-downY)<12) showPanel();
                        return true;
                } return true;
            }
        });
        wm.addView(bubble, bubbleParams);
    }
    private void showPanel() {
        if (panelContainer != null) return;
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(0x00000000);
        web = new WebView(this);
        web.setBackgroundColor(0x00000000);
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void closePanel() { new android.os.Handler(getMainLooper()).post(() -> hidePanel()); }
        }, "AndroidOverlay");
        web.loadUrl("file:///android_asset/panel.html");
        frame.addView(web, new FrameLayout.LayoutParams(-1, -1));
        panelContainer = frame;
        int width = Math.min(dp(420), getResources().getDisplayMetrics().widthPixels - dp(20));
        int height = Math.min(dp(570), getResources().getDisplayMetrics().heightPixels - dp(70));
        panelParams = new WindowManager.LayoutParams(width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.CENTER;
        wm.addView(panelContainer, panelParams);
    }
    private void hidePanel() {
        if (panelContainer != null) {
            try { wm.removeView(panelContainer); } catch(Exception ignored) {}
            panelContainer = null; web = null;
        }
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        hidePanel();
        if (bubble != null) { try { wm.removeView(bubble); } catch(Exception ignored) {} bubble=null; }
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
