package com.marinxit.overlay;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQUEST_OVERLAY = 4401;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(36, 48, 36, 36);
        TextView title = new TextView(this);
        title.setText("MARIN XIT\n\nPainel flutuante demonstrativo. Não se conecta ao Free Fire.");
        title.setTextSize(20);
        layout.addView(title);
        Button start = new Button(this);
        start.setText("Ativar bolinha flutuante");
        layout.addView(start);
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQUEST_OVERLAY);
            } else startOverlay();
        });
        setContentView(layout);
    }
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQUEST_OVERLAY && Settings.canDrawOverlays(this)) startOverlay();
    }
    private void startOverlay() {
        startService(new Intent(this, OverlayService.class));
        finish();
    }
}
